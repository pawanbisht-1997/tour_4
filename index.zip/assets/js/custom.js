// Header Sticky Here

    var headerOne = $(".navbar");
    $(window).on('scroll', function () {
      if ($(this).scrollTop() < 50) {
        headerOne.removeClass("header-fixed");
      } else {
        headerOne.addClass("header-fixed");
      }
    });
    
 $(window).scroll(function(){

  $('nav').toggleClass('scrolled', $(this).scrollTop() > 50);

});

// Search Section head

// $('#show-search-box').click(function(){
//   $("#hidden-search-box").toggle();
// });


$('#show-search-box').click(function() {
  $('#hidden-search-box').toggle();
  if ($('#hidden-search-box'))
  {
       $(this).addClass('active');   
  }
  else
  {
       $(this).removeClass('active');   
  }
});



// Mega menu


$('.carousel .carousel-item').each(function(){
  var minPerSlide = 4;
  var next = $(this).next();
  if (!next.length) {
  next = $(this).siblings(':first');
  }
  next.children(':first-child').clone().appendTo($(this));
  
  for (var i=0;i<minPerSlide;i++) {
      next=next.next();
      if (!next.length) {
        next = $(this).siblings(':first');
      }
      
      next.children(':first-child').clone().appendTo($(this));
    }
});

$(".hover").mouseleave(
  function() {
    $(this).removeClass("hover");
  }
);
